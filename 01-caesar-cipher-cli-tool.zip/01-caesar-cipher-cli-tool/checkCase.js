const isLowerCase = (string) => {
  if (string === string.toLowerCase()) return true
  return false
}